
<div id="page-container">
   <div id="content-wrap">
   <h3 id="footer"> Theme By <a href ="https://websiteparadise.net/">Website Paradise</a> </h3>
   </div>
   <footer id="footer"></footer>
 </div>

<?php wp_footer();?>
</body>
</html>